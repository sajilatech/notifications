
<?php phpinfo(); ?>