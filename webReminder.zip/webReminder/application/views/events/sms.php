
<main class="col-10 ">

          <div class="page-body">
  
              <div class="page-head">
                  <h2 class="float-start">Send SMS</h2>
                 
       
              </div>
              <?php 
					  if($this->session->flashdata('success_msg')){?>
					    <div style="color:green"><?=$this->session->flashdata('success_msg');?></div><?php  }
              
               if($this->session->flashdata('error_msg')){?>
                 <div style="color:red"><?php echo $this->session->flashdata('error_msg');?></div><?php  }
                  ?>
              <form role="form" method="post" enctype="multipart/form-data" action="<?php echo site_url("sms/add");?>" class="form-horizontal" id="cForm">
              <div id="message-box"></div>
              <div class="page-content">
        <div class="form-box">
            <div class="row">
                <div class="col-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">Enter your Phone number</label>+91
                        <input type="text" name="phone" id="phone" class="form-control" placeholder="Enter Phone Numbers" value="+91<?= set_value('phone'); ?>">
                        <div class="error" id="name_error"></div> <!-- Error for name -->
                    </div>
                <div class="modal-footer">
                    <input type="hidden" name="type" value="city">
                    <button type="submit" class="submit-primary btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
</form>

              </div>
              </div></div>
      </main>
    </div>
   