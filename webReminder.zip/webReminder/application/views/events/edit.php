
<main class="col-10 ">

          <div class="page-body">
  
              <div class="page-head">
                  <h2 class="float-start">Add Event</h2>
                  <div class="float-end"><a class="btns back-btn" href="<?php echo site_url('events');?>"><i class="lni lni-arrow-left"></i>Back</a></div>
       
              </div>
              <?php 
					  if($this->session->flashdata('success_msg')){?>
					    <div style="color:green"><?php echo $this->session->flashdata('success_msg');?></div><?php  }
              
               if($this->session->flashdata('error_msg')){?>
                 <div style="color:red"><?php echo $this->session->flashdata('error_msg');?></div><?php  }
                  ?>
              <form role="form" method="post" enctype="multipart/form-data" action="<?php echo site_url("events/update");?>" class="form-horizontal">
                        <div class="page-content">
                            <div class="form-box">
                              <div class="row">
                                <div class="col-6">
                                <div class="mb-3">
                                    <label for="title1" class="form-label"> Title </label>
                       
                                        <input type="text" name="title" id="title" class="form-control" placeholder="English"value=" <?=set_value('title')? set_value('title'): $row->title ?>" data-validation="required" >
                                        <?php echo form_error('title', '<div class="error">', '</div>'); ?>
                                </div>
                              
                                <div class="mb-3">
                                    <label for="title1" class="form-label"> Location </label>
                       
                                        <input type="text" name="location" id="location" class="form-control" placeholder="English"value=" <?=set_value('location') ?set_value('location'): $row->location?>" data-validation="required" >
                                        <?php echo form_error('location', '<div class="error">', '</div>'); ?>
                           
                                </div>
                                <div class="mb-3">
                                <div class="row">
                                <div class="col"> 
                                    <label for="title1" class="form-label"> Time From </label>
                       
                                        <input type="time" name="time_from" id="title" class="form-control" placeholder="English"value="<?=set_value('time_from')? set_value('time_from'):$row->time_from ?>" data-validation="required" >
                                        <?php echo form_error('time_from', '<div class="error">', '</div>'); ?>
                                </div>
                                <div class="col"> 
                                    <label for="title1" class="form-label"> Time To </label>
                       
                                        <input type="time" name="time_to" id="title" class="form-control" placeholder="English" value="<?=set_value('time_to')?set_value('time_to'): $row->time_to ?>" data-validation="required" >
                                        <?php echo form_error('time_to', '<div class="error">', '</div>'); ?>
                                </div>
               </div>
               </div>
               <div class="mb-3">
                          
                          <label for="name" class="form-label">Date </label>
               <input type="text" name="date" class="form-control datepicker" id="datepick" value="<?=set_value('date')?set_value('date'): $row->date?>" placeholder="Start Date" data-validation="required">
                               
               </div> 
               <div class="mb-3">
                          
                          <label for="name" class="form-label">Description </label>
                          <textarea  name="desc" class="form-control" data-validation="required"><?=set_value('desc')?set_value('desc'): $row->description?></textarea>
                         
                                    <?php echo form_error('desc', '<div class="error">', '</div>'); ?>
                          </div>
                          
                                    </div>
                           

                          </div>

                            
                                      </div>
                                     
                                    
						  <div class="modal-footer">
                            <input type="hidden" value="<?=$row->id?>" name="pri_id">
								<button type="submit" class="submit-primary">Save</button>
							</div>
							</form>

              </div>
              </div></div>
      </main>
    </div>
  



