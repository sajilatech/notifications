 <link href="<?=base_url('assets/css/pagination.css')?>" rel="stylesheet">
 <style>
     .image-container img {
    display: inline-block;
    margin-right: 5px;
}
 </style>
<main class="col-10 ">
          <div class="page-body">
  
              <div class="page-head">
        <h2 class="float-start">Events</h2>
                  <div class="float-end"><a class="btns" href="<?php echo site_url("events/create");?>"><i class="lni lni-plus"></i>Add New</a></div>
       
              </div>
              <?php if($this->session->flashdata('success_msg')){ ?>
				<div class="alert alert-success alert-dismissible show" role="alert">
					<?php echo $this->session->flashdata('success_msg');?>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<?php } ?>
				<?php if($this->session->flashdata('warning_msg')){ ?>
				<div class="alert alert-warning alert-dismissible show" role="alert">
					<?php echo $this->session->flashdata('warning_msg');?>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<?php } ?>
				<?php if($this->session->flashdata('error_msg')){ ?>
				<div class="alert alert-danger alert-dismissible show" role="alert">
					<?php echo $this->session->flashdata('error_msg');?>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<?php } ?>
				<div class="top-filter">
                <div class="row">
                            <div class="col-lg-3 col-md-3 col-12">
                                <label>Title</label>
                                <input type="text" name="company_name" class="form-control" placeholder="<?=$this->lang->line('company'); ?>" id="company_name">
                                </div>
                    
                 
                            <div class="col-lg-3 col-md-3 col-12">
                                <label>From</label>
                                <input type="text" name="fdate" class="form-control datepicker" id="datepick"  placeholder="<?=$this->lang->line('from'); ?>" >

                            </div>
                                <div class="col-lg-3 col-md-3 col-12">
                                    <label>To</label>
                                    <input type="text" name="tdate" class="form-control datepicker" placeholder="<?=$this->lang->line('to'); ?>" id="datepick1">
                                        

                                </div>
                                <div class="col-lg-2 col-md-2 col-12">
                                    <label> </label><br>
                                            <div class="form-group">
                                                <button class="btn btn-block btn-outline-dark" type="submit" style="height: 35px; width:120px" onclick="return myfunction4()"><?=$this->lang->line('search'); ?></button>
                                                <a href="javascript:;" onclick="location.reload()" class="btn btn-default"><i style="font-size:20px" class="fa">&#xf021;</i> <?=$this->lang->line('refresh'); ?></a>
                                            </div>
                              </div>
                            
                              </div>
                </div>
							  <div id="transport_bk">
                                            <div class="page-content">
                                            <table  class="table table-striped table-bordered" >
                                    <thead>
                                    <tr>
                                                                                            <th>Sl:No</th>
                                                                                            <th>Title</th>
                                                                                            <th>Location</th>
                                                                                            <th>From</th>
                                                                                            <th>To</th>
                                                                                            <th>Date</th>
                                                                                            <th>Status</th>
                                                                                            <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
        
         
	                                <?php if(!empty($table_rows)){
															$i=1;
															foreach( $table_rows as $row){ 
														?>
															<tr>
															<td><?=$i;?></td>
															<td><?=$row->title?></td>
															<td><?=$row->location?></td>
                                                            <td><?=$row->time_from?></td>
															<td>
                                                            <?=$row->time_to?>
														</td>
                                                       
                                                    </td>
															<td><?=$row->date ;?></td>
															
															<td><?php if($row->status==1) { ?>
																<div class="btn btn-sm btn-success">Active</div>
																<?php } else { ?>
																<div class="btn btn-sm btn-danger">Inactive</div>
																<?php } ?>
															</td>
															<td>
															    <div class="dropdown">
                                                                    <button class="btn btn-green dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <?=$this->lang->line('actions'); ?>
                                                                    </button>
                                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                        	<?php if($row->status==1) { ?>
                                                                      <li><a class="dropdown-item" href="<?php echo site_url("events/status/".$row->id."/1");?>">Deactivate</a></li>
                                                                      	<?php } else { ?>
                                                                      <li><a class="dropdown-item" href="<?php echo site_url("events/status/".$row->id."/0");?>">Activate</a></li>
                                                                      	<?php } ?>
                                                                      <li><a class="dropdown-item" href="<?=site_url('events/edit')?>/<?=$row->id?>">Edit</a></li>
                                                                    
                                                                    </ul>
                                                                  </div>
															</td>
															</tr>
															<?php $i++;}
															}else{
																echo "There is no data Found! ";
															}?>
                                                </tbody>
                                            </table>   <div class="bottom-container">
  <div class="pagination" id="ajax_pg"><?php echo $links; ?></div></div>
                                                                                                    </div>
                                                        </div>
              </div>
      </main>
    </div>
	<script type="text/javascript">
    function myfunction4()
    {
        var company_name=$("#company_name").val();
		
        fdate=$("#datepick").val();
        tdate=$("#datepick1").val();

        $.ajax({

            url: "<?php echo site_url('company/search_list');?>",
            type: "POST",
            data: {'company_name': company_name, from: fdate,to: tdate},
            dataType: "html",
            success: function(response){ 
                $("#transport_bk").html(response);


            }
            
        });
    }
</script>

<script>
    $( document ).ready(function() {
        paginate();
    });

    function paginate() {
        $(document).on('click', '#ajax_pg a', function(event) {

            event.preventDefault();

            var url = $(this).attr('href');
            $.ajax({
                type: 'get',
                url: url,
                dataType:"html",
                success: function(data)
                {

                
                    $("#transport_bk").html(data);
                }
            });
        });
    }


</script>