<main class="col-10 ">
          <div class="page-body">
      
          <!-- Content Area -->
          <h1><?php echo "Welcome, " . $this->session->userdata('name');?></h1>
          <!-- Add your content here -->
        
              </div>
      </main>
    </div>