  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.1/moment.min.js"></script>-->
<!-- <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script> -->
    <!-- DataTables JS -->
<!-- <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
 <!-- Bootstrap 5 JavaScript (including Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> 
  <script>
<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include Bootstrap CSS -->
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->

<!-- Include Bootstrap Datepicker CSS -->
<link rel="stylesheet" href="path/to/bootstrap-datepicker.min.css">

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      var sidebarMenu = document.getElementById("sidebarMenu");
      var navbarToggler = document.querySelector(".navbar-toggler");

      navbarToggler.addEventListener("click", function() {
        sidebarMenu.classList.toggle("active");
      });
    });

  $(document).ready(function() {
    $('.selectbox').select2();
  });

      $(document).ready(function() {
    $('#data-tables').DataTable();
  });
  
  

  
     $(document).ready(function() {
    $('.datepicker').datepicker({
      format: 'yyyy-mm-dd',
      todayHighlight: true,
      autoclose: true
    });
  });

     
  </script>
<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url();?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url();?>dist/js/jquery-ui.min.js"></script>

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>


<!-- Morris.js charts -->
<script src="<?php echo base_url();?>dist/js/raphael-min.js"></script>
<!--<script src="plugins/morris/morris.min.js"></script>-->
<!-- Sparkline -->
<script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url();?>plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url();?>dist/js/moment.min.js"></script>
<script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url();?>plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?php echo base_url();?>plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- bootstrap date time picker -->
<script src="<?php echo base_url();?>plugins/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url();?>plugins/fastclick/fastclick.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo base_url();?>plugins/iCheck/icheck.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>dist/js/app.min.js"></script>

<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- DataTables -->
<!--<script src="<?php echo base_url();?>plugins/datatables/jquery.dataTables.min.js"></script>-->
<!--<script src="<?php echo base_url();?>plugins/datatables/dataTables.bootstrap.min.js"></script>-->
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>dist/js/demo.js"></script>
<script src="<?=base_url('assets/js/jquery-confirm.min.js')?>"></script>
<script src="<?=base_url('assets/js/jquery.toast.min.js')?>"></script>
<script src="<?=base_url('assets/js/jquery.blockUI.js')?>"></script>
<?php if($this->uri->segment(1) == 'ma_flight_discounts' || $this->uri->segment(1) == 'ma_flight_discount' || $this->uri->segment(1) == 'ma_offline_entries' || $this->uri->segment(1) == 'ma_flight_entries' || $this->uri->segment(1) == 'ma_flight_inventory' || $this->uri->segment(1) == 'ma_subclass_blocking' || $this->uri->segment(1) == 'ma_contract') { ?>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-select.min.css">
<script src="<?php echo base_url();?>assets/js/bootstrap-select.min.js"></script>
<?php } ?>
<?php if($this->uri->segment(1) == 'ma_flight_discounts' || $this->uri->segment(1) == 'ma_flight_discount' || $this->uri->segment(1) == 'ma_flight_inventory' || $this->uri->segment(1) == 'ma_flight_entries' || $this->uri->segment(1) == 'ma_subclass_blocking' || $this->uri->segment(1) == 'holiday_package' || $this->uri->segment(1) == 'ma_contract') { ?>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ajax-bootstrap-select.min.css">
<script src="<?php echo base_url();?>assets/js/ajax-bootstrap-select.min.js"></script>
<?php } ?>
<?php if ( in_array(strtolower(trim($this->uri->segment(1))),  ['visa_types','questionnaire','questionnaire_new','questionnaires','visa_enquiries','vacation_package','my_explore','country','contact_enquiries','consultation_types','consultation_subtypes','visa_appointments','visa_lists','visa_cms_home','visa_cms_search','tour_bookings','visa_bookings','free_consultation','applications','hotel','gousers','gowallet','goschools','goquestionnaire']) ) { ?>
<link rel="stylesheet" href="<?=base_url('assets/css/bootstrap-select.min.css')?>">
<link rel="stylesheet" href="<?=base_url('assets/css/ajax-bootstrap-select.min.css')?>">
<script src="<?=base_url('assets/js/bootstrap-select.min.js')?>"></script>
<script src="<?=base_url('assets/js/ajax-bootstrap-select.min.js')?>"></script>
<script src="<?=base_url('assets/js/image-uploader.min.js')?>"></script>
<script src="<?=base_url('assets/js/ajax.countries.js')?>"></script>
<?php } else if ( in_array(trim($this->uri->segment(1)),  ['holiday_package','tour_package','luxury']) ) { ?>
<link rel="stylesheet" href="<?=base_url('assets/css/bootstrap-select.min.css')?>">
<link rel="stylesheet" href="<?=base_url('assets/css/ajax-bootstrap-select.min.css')?>">
<script src="<?=base_url('assets/js/bootstrap-select.min.js')?>"></script>
<script src="<?=base_url('assets/js/ajax-bootstrap-select.min.js')?>"></script>
<script src="<?=base_url('assets/js/ajax.countries.js')?>"></script>
<?php } ?>
<?php if ( file_exists('assets/js/'.str_replace('_', '.', strtolower(trim($this->uri->segment(1)))).'.js') ) { ?>
<script src="<?=base_url('assets/js/'.str_replace('_', '.', strtolower(trim($this->uri->segment(1)))).'.js')?>?v=2.2"></script>
<?php } ?>
<?php if($this->uri->segment(1) != "luxury"){ ?>
<script src="<?=base_url()?>assets/js/script.js"></script>
<?php }else{ ?>
<script src="<?=base_url()?>assets/js/luxury.js"></script>
<?php } ?>
<script>
  $(function () {
	<?php if($this->uri->segment(1) == 'ma_flight_discounts' || $this->uri->segment(1) == 'ma_flight_discount') { ?>
		$('.select2').selectpicker();
		$('.select2airport').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_discount/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					airport : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].code,
							value: data[i].code,
							data: {
								subtext: data[i].text
							}
						}));
					}
				}
				return array;
			}

		});
		
		$('.select2airline').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_discount/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					airline : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].code,
							value: data[i].code,
							data: {
								subtext: data[i].text
							}
						}));
					}
				}
				return array;
			}

		});
	<?php } else if($this->uri->segment(1) == 'ma_flight_inventory') { ?>
		$('.select2').selectpicker();
		$('.select2airport').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_inventory/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					airport : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].code,
							value: data[i].code,
							data: {
								subtext: data[i].text
							}
						}));
					}
				}
				return array;
			}

		});
		
		$('.select2airline').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_inventory/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					airline : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].code,
							value: data[i].code,
							data: {
								subtext: data[i].text
							}
						}));
					}
				}
				return array;
			}

		});
	<?php } else if($this->uri->segment(1) == 'ma_flight_entries') { ?>
		$('.select2').selectpicker();
		$('.select2discounts').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_entries/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					discount : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].text,
							value: data[i].code
						}));
					}
				}
				return array;
			}

		});
		$('.select2inventory').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_entries/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					inventory : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].text,
							value: data[i].code
						}));
					}
				}
				return array;
			}

		});
		$('.select2airline').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_flight_entries/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					airline : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].code,
							value: data[i].code,
							data: {
								subtext: data[i].text
							}
						}));
					}
				}
				return array;
			}

		});
	<?php } else if($this->uri->segment(1) == 'ma_offline_entries') { ?>
		$('.select2').selectpicker();
	<?php } elseif($this->uri->segment(1) == 'holiday_package'){ ?>
		
		$('.destination').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('holiday_package/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					location : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].name+', ' + data[i].nicename,
							value: data[i].id+','+data[i].c_id
						}));
					}
				}
				return array;
			}

		});
	<?php } elseif($this->uri->segment(1) == 'ma_contract'){ ?>
		
		$('.destination').selectpicker().ajaxSelectPicker({
			ajax: {
				url: "<?=site_url('ma_contract/ajaxloader')?>",
				type: 'POST',
				dataType: 'json',
				data: {
					location : '{{{q}}}'
				}
			},

			// function to preprocess JSON data
			preprocessData: function (data) {
				var i, l = data.length,
					array = [];
				if (l) {
					for (i = 0; i < l; i++) {
						array.push($.extend(true, data[i], {
							text: data[i].name+', ' + data[i].nicename,
							value: data[i].id+','+data[i].c_id
						}));
					}
				}
				return array;
			}

		});
	<?php } ?>
	
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
    $('#example3').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageLength": 100
    });
    $('#example4').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageLength": 500
    });
    $("#example5").DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "pageLength": 100
    });
    //Timepicker
    $(".timepicker").timepicker({
      showInputs: false
    });
    //Timepicker
    $("#timepicker1").timepicker({
      showInputs: false,
      showMeridian: false,
      minuteStep: 1,
    });
    //Timepicker
    $(".timepicker2").timepicker({
      showInputs: false,
      showMeridian: false,
      minuteStep: 1,
    });
    //datepicker
    $('#datepicker').datepicker({
      format: "d M yyyy"
    });
    //datepicker1
    $('#datepicker1').datepicker({
      format: "d M yyyy"
    });
    //datepicker
    $('#datepick').datepicker({
      format: "yyyy-mm-dd"
    });
     //datepicker1
    $('#datepick1').datepicker({
      format: "yyyy-mm-dd"
    });
	$('.datepick1').datepicker({
      format: "yyyy-mm-dd"
    });
    $('#datepick2').datepicker({
      format: "yyyy-mm-dd"
    });
    //date
    $('#date').datepicker({
      format: "mm-yyyy"
    });
     //date1
    $('#date1').datepicker({
      format: "mm-yyyy"
    });
	
	<?php if($this->uri->segment(1) == 'ma_flight_discounts' 
	|| $this->uri->segment(1) == 'ma_flight_discount' 
	|| $this->uri->segment(1) == 'ma_promocode' 
	|| $this->uri->segment(1) == "ma_b2c_reports" 
	|| $this->uri->segment(1) == "ma_flight_booking" 
	|| $this->uri->segment(1) == 'ma_offline_entries' 
	|| $this->uri->segment(1) == 'ma_flight_inventory' 
	|| $this->uri->segment(1) == 'ma_flight_entries'
	|| $this->uri->segment(1) == 'tour_package'
	|| $this->uri->segment(1) == 'Gopaddi') { ?>
	
	$('#flight_date').datepicker({
		format: "yyyy-mm-dd",
		// startDate: '+0d',
		todayHighlight: true,
		autoclose: true
    }).on('changeDate', function(ev) {  
		if($(this).val()) {
			$(this).removeClass('has-error');
			$(this).css('border-color', '');
			$('#flight-date-error').hide();
			$('#flight-date-error').html('');
			$('#flight-date-error').removeClass('has-error');
			$('#flight-date-error').addClass('has-success');
		}
	});
	
	// flight discount module
    $('.dateonly').datetimepicker({
		showClose: false,
		showClear: false,
		useCurrent: false,
		format: 'YYYY-MM-DD',
		ignoreReadonly: true,
	}).on('dp.hide', function (e) {
		if( e.date ) { 
			if( $(this).attr('id') == 'start_dateonly' ) {
				$('#expiry_dateonly').data("DateTimePicker").date(e.date);
			}
		}
	});
	
	var todayOnVisa = new Date().setHours(0,0,0,0);
	var minDateVisa = new Date().setHours(0,0,0,0);
	<?php if($this->uri->segment(2) == 'update') { ?>
	<?php if(isset($model->start_from)) { ?>
	var ifExistDate = '<?=$model->start_from?>';
	<?php } else if(isset($model->start_date)) { ?>
	var ifExistDate = '<?=$model->start_date?>';
	<?php } else { ?>
	var ifExistDate = '';
	<?php } ?>
	if(ifExistDate) {
		if( new Date(ifExistDate).setHours(0,0,0,0) < todayOnVisa ) {
			minDateVisa = new Date(ifExistDate).setHours(0,0,0,0);
		}
	}
	<?php } ?>
	
	// start date 0n discount/promocode module
//     $('#start_from').datetimepicker({
// 		format: 'YYYY-MM-DD HH:mm:ss',
// 		showClose: true,
// 		useCurrent: false,
// 		ignoreReadonly: true
// 	}).on('dp.hide', function (e) {
// 		if( e.date ) { 
// 			if( parseInt(e.date.format('x')) >= parseInt(todayOnVisa)) {
// 				e.date.add(15, 'minutes');
// 				$('#expire_on').data("DateTimePicker").minDate(e.date);
// 			}
// 		}
// 	});
	
	// expiry date 0n discount/promocode module
//     $('#expire_on').datetimepicker({
// 		minDate: todayOnVisa,
// 		format: 'YYYY-MM-DD HH:mm:ss',
// 		showClose: true,
// 		useCurrent: false,
// 		ignoreReadonly: true
// 	});
	
	// expiry date 0n entries module
// 	$('#exp_date').datetimepicker({
// 		format: 'YYYY-MM-DD HH:mm:ss',
// 		showClose: true,
// 		showClear: true,
// 		ignoreReadonly: true,
// 		useCurrent: false,
// 		icons : { close: 'glyphicon glyphicon-ok' }
// 	}).on('dp.hide', function (e) {
// 		entriesFilter($.trim($(this).val()));
// 	});
	
// 	$('#exp_date1').datetimepicker({
// 		format: 'YYYY-MM-DD HH:mm:ss',
// 		showClose: true,
// 		showClear: true,
// 		ignoreReadonly: true,
// 		useCurrent: false,
// 		icons : { close: 'glyphicon glyphicon-ok' }
// 	}).on('dp.hide', function (e) {
// 		entriesFilter($.trim($(this).val()));
// 	});
// 	// departure date 0n inventory module
// 	$('body').on('focus', ".departure_date", function(){
//         $(this).datetimepicker({
// 			format: 'YYYY-MM-DD HH:mm:ss',
// 			showClose: true,
// 			useCurrent: false,
// 			ignoreReadonly: true
// 		});
//     });
	
// 	// arrival date 0n inventory module
// 	$('body').on('focus', ".arrival_date", function(){
//         $(this).datetimepicker({
// 			format: 'YYYY-MM-DD HH:mm:ss',
// 			showClose: true,
// 			useCurrent: false,
// 			ignoreReadonly: true
// 		});
//     });
	
// 	$('body').on('focus', ".datetime", function(){
//         $(this).datetimepicker({
// 			format: 'YYYY-MM-DD HH:mm:ss',
// 			showClose: true,
// 			useCurrent: false,
// 			ignoreReadonly: true
// 		});
//     });
	
// 	<?php } ?>
	
	<?php if($this->uri->segment(1) == 'ma_flight_discount' && 
	$this->uri->segment(2) == 'update' && isset($model)) { ?>
		existance();
	<?php } ?>
	
	<?php if($this->uri->segment(1) == 'ma_flight_discounts' && 
	$this->uri->segment(2) == 'update' && isset($model)) { ?>
		uniqueness();
	<?php } ?>
	
  });
</script>
<!-- CK Editor -->
<script src="<?php echo base_url();?>dist/js/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    //CKEDITOR.replace('editor1');
    //bootstrap WYSIHTML5 - text editor
    $(".textarea").wysihtml5();
  });
</script>
<!--<script src="<?php echo base_url();?>dist/validator/form-validator/jquery.form-validator.min.js"></script>-->
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
	$.validate({
	  validateOnBlur : false, // disable validation when input looses focus
	  errorMessagePosition : 'inline' ,// Instead of 'inline' which is default
	  scrollToTopOnError : true, // Set this property to true on longer forms
	  modules : 'file'
	});
</script>

<script type="text/javascript">
  function myfunction1(sid)
  {
   
  
   $.ajax({
  url: "<?php echo site_url('ma_subagent/credit_display');?>",
  type: "POST",
  data: {subid: sid},
  dataType: "json",
  success: function(response){
   
    $("#credit_table").html(response);
    $("#credit_limit").modal('show');

  }
});
  }
</script>

<script type="text/javascript">
  function myfunction2(sid)
  {
   
  
   $.ajax({
  url: "<?php echo site_url('ma_subagent/wallet_display');?>",
  type: "POST",
  data: {subid: sid},
  dataType: "json",
  success: function(response){
   
    $("#credit_table").html(response);
    $("#credit_limit").modal('show');

  }
});
  }
</script>
<script type="text/javascript">
    function myfunction5(sid)
    {


        $.ajax({
            url: "<?php echo site_url('ma_visa/credit_display');?>",
            type: "POST",
            data: {subid: sid},
            dataType: "json",
            success: function(response){

                $("#credit_table").html(response);
                $("#credit_limit").modal('show');

            }
        });
    }
</script>
<script type="text/javascript">
  function infofunction(sid,pid)
  {
   $.ajax({
  url: "<?php echo site_url('ma_talley/info_display');?>",
  type: "POST",
  data: {subid: sid, parid: pid},
  dataType: "json",
  success: function(response){
   
    $("#info_table").html(response);
    $("#info_limit").modal('show');

  }
});
  }
</script>
<script>//Ashik Abbas 23-1-2019
$('#branch').on('change', function(){
	var branch = this.value;
	$.ajax({
	  url: "<?php echo site_url('ma_voucher/getagents');?>",
	  type: "POST",
	  data: {branch: branch},
	  dataType: "json",
	  success: function(response){
		 $('select#agent').find('option').remove().end();
		 $.each(response, function(key,val) {        
			$("select#agent").append( $("<option>").val(val.subagent_id).html(val.subagent_name));
		 });
	  }
    });
});
$('#branchs').on('change', function(){
	var branch = this.value;
	$.ajax({
	  url: "<?php echo site_url('ma_voucher/getagents');?>",
	  type: "POST",
	  data: {branch: branch},
	  dataType: "json",
	  success: function(response){
		 $('select#agents').find('option').remove().end();
		 $.each(response, function(key,val) {        
			$("select#agents").append( $("<option>").val(val.subagent_id).html(val.subagent_name));
		 });
		 $("#walk").removeAttr("disabled");
	  }
    });
});
$("#agents").on('change', function(){
	if($(this).val() !=''){
		$("#walk").removeAttr("disabled");
	}
});
$('#received_amount').on('input propertychange paste', function() {
	calculate1();
});
$('#balance_amount').on('input propertychange paste', function() {
	calculate1();
});
function calculate1(){
	
	var received = $("#received_amount").val();
	var balance = $("#balance_amount").val();
	if(received.length != 0 && balance.length != 0){
	var total = parseFloat(received)-parseFloat(balance);
	$("#total_amount").val(total);
	}else if(received.length != 0 && balance.length == 0){
		$("#total_amount").val(received);
	}else{
		$("#total_amount").val(0);
	}
}
function filtervoucher(){
	var branch = $("#branch").val();
	var agent  = $("#agent").val();
	var date   = $("#datepicker").val();
	$.ajax({
	  url: "<?php echo site_url('ma_voucher/filtervoucher');?>",
	  type: "POST",
	  data: {branch: branch,agent: agent,date: date},
	  success: function(response){
		  $("#newtable").html(response);
	  }
    });
}
$('#actpaid').on('change', function() {
    var tot = $("#totamnt").val();
    var act = $("#actpaid").val();
	$('#balamnt').val('0.00');
	if(parseFloat(act)<parseFloat(tot)){
		alert('Actual Paid Amount Cant Be Less Than Total Amount');
		$('#actpaid').val(tot);
		$('#balamnt').val('0.00');
	}else{
		if(act.length != 0 ){
			var diff = parseFloat(act)-parseFloat(tot);
			$('#balamnt').val(diff);
		}else{
			$('#balamnt').val('0.00');
		}	
	}
});
function selectAll(){
	var atLeastOneIsChecked = $('#chkAll:checkbox:checked').length > 0;
	if(atLeastOneIsChecked ==true){
		$('.chk').prop('checked', true);
		calculate();
	}else{
		$('.chk').prop('checked', false);
		empty();
	}
};
function calculate(){
	$("#create").removeAttr("disabled");
	var yourArray = new Array();
	var suming =0;
	var id = new Array();
	$(".chk:checkbox:checked").each(function(){
		yourArray.push($(this).val());
		id.push($(this).attr('title'));
		suming = parseFloat(suming)+parseFloat($(this).val());
	});
	var blkstr = [];
	$.each(id, function(idx2,val2) {                    
	  var str = val2;
	  blkstr.push(str);
	});
	var newids = blkstr.join(",");
	$("#ids").val(newids);
	$("#totamnt").val(suming.toFixed(2));
	$("#actpaid").val(suming.toFixed(2));
	$("#balamnt").val('0.00');
}
function add(a, b){
    return a + b;
}
function empty(){
	$("#totamnt").val('0.00');
	$("#actpaid").val('0.00');
	$("#balamnt").val('0.00');
	$("#ids").val('');
	$("#create").attr("disabled", true);
}
$('#method_payment').on('change', function() {
	if($(this).val() =='bank'){
	$("#bank_details").html('<div class="col-md-4">'+
							'<label><font color="red">*</font> Transfer Method</label>'+
							'<select class="form-control" id="transfer_method" name="transfer_method">'+
								'<option value="wire">Wire Transfer</option>'+
								'<option value="cheque">Cheque</option>'+
							'</select>'+
						'</div>'+
						'<div class="col-md-4">'+
							'<label>Transfer Reference/Cheque Id</label>'+
							'<input type="text" name="refernce_no" class="form-control"/>'+
						'</div>');
	}else{
			$("#bank_details").html('');
	}
    //alert('sdd');
});
</script>

<!-- created on 17-04-19 -->
<script type="text/javascript">
	$('#one_discount').on('change', function() {
		$('#one_price').removeAttr('data-validation');
		$('#one_price').removeAttr('data-validation-length');
		$('#one_price').attr('data-validation', 'required number');
		if($(this).val() == 'percent') {
			$('#one_price').attr('data-validation', 'required number length');
			$('#one_price').attr('data-validation-length', 'max2');
			$('#one_price').attr('data-validation-allowing', 'range[1;100000]');
		} else {
			$('#one_price').attr('data-validation-allowing', 'range[0;100000]');
		}
	});
	$('#round_discount').on('change', function() {
		$('#round_price').removeAttr('data-validation');
		$('#round_price').removeAttr('data-validation-length');
		$('#round_price').attr('data-validation', 'required number');
		if($(this).val() == 'percent') {
			$('#round_price').attr('data-validation', 'required number length');
			$('#round_price').attr('data-validation-length', 'max2');
			$('#round_price').attr('data-validation-allowing', 'range[1;100000]');
		} else {
			$('#round_price').attr('data-validation-allowing', 'range[0;100000]');
		}
	});
</script>
<script>
	$('#markup_type').on('change', function() {
		if($(this).val() == 'percent') {
			$('#markup_price').attr('data-validation-allowing', 'range[1;100000]');
		} else {
			$('#markup_price').attr('data-validation-allowing', 'range[0;100000]');
		}
	});
</script>
<!-- created on 17-04-19 -->
<script type="text/javascript">
	$('select#from_destination').on('change', function() {
		if( $('select#to_destination :selected').val() == $(this).val() ) {
			$('select#to_destination').val('').trigger('change');
		}
	});
	$('select#to_destination').on('change', function() {
		$(this).parent().removeClass('has-error');
		$(this).parent().children('span#to-error').remove();
		if( $('select#from_destination :selected').val() == $(this).val() ) {
			$(this).val('').trigger('change');
			$(this).parent().addClass('has-error');
			$(this).parent().append('<span id="to-error" class="help-block form-error">That option already selected in the above field.</span>');
		}
	});
</script>
<!-- created on 17-04-19 -->
<script type="text/javascript">
	$('input#promocode').on('blur', function() {
		if($(this).val().trim()) {
			$.ajax({
				type: 'post',
				url: "<?=site_url('ma_promocode/is_unique')?>",
				data: { "code" : $(this).val().trim() },
				dataType: 'json',
				beforeSend: function() {
					$('input#promocode').parent().addClass('has-success');
					$('input#promocode').parent().children('span#promocode-error').remove();
				},
				success: function (result) {
					if (result.message) {
						$('input#promocode').parent().addClass('has-error');
						$('input#promocode').parent().append('<span id="promocode-error" class="help-block form-error">'+result.message+'</span>');
					}
					$('input#promocode').parent().removeClass('has-error');
				},
			});
		}
	});
</script>
<?php if($this->uri->segment(1) == 'ma_flight_discount') { ?>
<script>
	$("[name='trip_type[]'][type='checkbox']:eq(0)")
  	.valAttr('','validate_checkbox_group')
  	.valAttr('qty','min1')
  	.valAttr('error-msg','This is a required field');
</script>
<script type="text/javascript">
	function existance() {
		
		var cabinclass	= $('select#cabinclass :selected').val().trim();
		var airlinecode = $('select#airlinecode :selected').val().trim();
		if(cabinclass && airlinecode) {
			$.ajax({
				type: 'post',
				url: "<?=site_url('ma_flight_discount/existance')?>",
				data: { 
					"airline" : airlinecode, 
					"class" : cabinclass, 
					"row" : $('input[name="row"]').val() 
				},
				dataType: 'json',
				beforeSend: function() {
					$('div#existance').removeClass('show');
					$('div#existance').addClass('hide');
					$('input#validate').val('');
				},
				success: function (result) {
					if (result) {
						$('div#existance').removeClass('hide');
						$('div#existance').addClass('show');
						$('input#validate').val(1);
						$(window).scrollTop(0);
					}
				},
			});
		}
	}
	$("form#discount-form").submit(function(e) {
		if ($('input#validate').val().trim()) {
			e.preventDefault(e);
		}
	});
</script>
<?php } ?>
<?php if($this->uri->segment(1) == 'ma_flight_discounts') { ?>
<script>
	$("[name='trip_type[]'][type='checkbox']:eq(0)")
  	.valAttr('','validate_checkbox_group')
  	.valAttr('qty','min1')
  	.valAttr('error-msg','This is a required field');
</script>
<script type="text/javascript">
	function uniqueness(id = 0) {
		
		var row = '';
		<?php if($this->uri->segment(2) != 'clones') { ?>
		if($('input[name="row"]').length) {
			row = $('input[name="row"]').val();
		}
		<?php } ?>
		
		if($('input#origin').length) {
			var origin		= $('input#origin').val().trim();
		} else {
			var origin		= $('select#origin :selected').val().trim();
		}
		
		if($('input#destination').length) {
			var destination	= $('input#destination').val().trim();
		} else {
			var destination	= $('select#destination :selected').val().trim();
		}
		
		if($('input#airlinecode').length) {
			var airlinecode = $('input#airlinecode').val().trim();
		} else {
			var airlinecode = $('select#airlinecode :selected').val().trim();
		}
		
		if($("select#cabin-"+id).length) {
			var cabinclass	= $("select#cabin-"+id+" :selected").val().trim();
		} else {
			var cabinclass	= $('select#cabinclass :selected').val().trim();
		}
		
		if($("input#class-"+id).length) {
			var classcabin	= $("input#class-"+id).val().trim();
		} else {
			var classcabin	= $('input#classcabin').val().trim();
		}
		
		// spot restriction
		if($("input#class-"+id).length) {
			var classes = []; 
			$("input[name='class[]']").each(function() {
				var rel = $(this).attr('rel');
				var ccabin = $("select#cabin-"+id+" :selected").val().trim();
				var cclass = $(this).val().trim();
				if( $(this).attr('id') != "class-"+id ) {
					classes.push(ccabin+cclass);
				}
			});
			
			if(jQuery.inArray(cabinclass+classcabin, classes) !== -1) {
				$('input#validate').val(1);
				$('#class-'+id+'-error').html('<span class="help-block form-error">Already selected</span>');
				$('#class-'+id+'-error').removeClass('has-success');
				$('#class-'+id+'-error').addClass('has-error');
			} else {
				$('input#validate').val('');
				$('#class-'+id+'-error').html('');
				$('#class-'+id+'-error').removeClass('has-error');
				$('#class-'+id+'-error').addClass('has-success');
			}
		}
		
		if(origin && destination && cabinclass && classcabin && airlinecode) {
			
			$.ajax({
				type: 'post',
				url: "<?=site_url('/ma_flight_discounts/uniqueness')?>",
				data: { 
					"destination" : destination, 
					"airline" : airlinecode, 
					"origin" : origin, 
					"cabin" : cabinclass, 
					"class" : classcabin, 
					"row" : row 
				},
				dataType: 'json',
				beforeSend: function() {
					$('div#uniqueness').removeClass('show');
					$('div#uniqueness').addClass('hide');
					$('input#validate').val('');
				},
				success: function (result) {
					if (result) {
						$('div#uniqueness').removeClass('hide');
						$('div#uniqueness').addClass('show');
						$('input#validate').val(1);
						$(window).scrollTop(0);
					}
				},
			});
		} else {
			$('div#uniqueness').removeClass('show');
			$('div#uniqueness').addClass('hide');
			$('input#validate').val('');
		}
	}
	
	$("form#discount-form").submit(function(e) {
		if ($('input#validate').val().trim()) {
			e.preventDefault(e);
		}
	});
	
	
	<?php if(isset($model)) { ?>
	$('body').on('click','button#clone-create',function() {
		var count = $("div.bb-middle").children().length;
		var clone = count;
		$("div.bb-middle").append(
			'<div class="clone-tab" id="clone-'+count+'">' +
				'<div class="col-md-12">' +
					'<div class="row">' +
						'<div class="col-md-4">' +
							'<div class="form-group">' +
								'<label class="control-label">Cabin <sup>*</sup></label>' +
								'<select name="cabin[]" id="cabin-'+count+'" class="form-control select2" title="- - Select - -" rel="'+count+'" data-live-search="true" data-validation="required" onchange="uniqueness('+count+')">' +
									'<option value="Y" <?php if($model->cabin == 'Y') { echo "selected"; } ?>>Economy</option>' +
									'<option value="C" <?php if($model->cabin == 'C') { echo "selected"; } ?>>Business</option>' +
									'<option value="F" <?php if($model->cabin == 'F') { echo "selected"; } ?>>First Class</option>' +
									'<option value="S" <?php if($model->cabin == 'S') { echo "selected"; } ?>>Premium Economy</option>' +
									'<option value="J" <?php if($model->cabin == 'J') { echo "selected"; } ?>>Premium Business</option>' +
									'<option value="P" <?php if($model->cabin == 'P') { echo "selected"; } ?>>Premium First Class</option>' +
								'</select>' +
							'</div>' +
						'</div>' +
						'<div class="col-md-4">' +
							'<div class="form-group">' +
								'<label class="control-label">Class <sup>*</sup></label>' +
								'<input type="text" name="class[]" id="class-'+count+'" class="form-control uppercase" placeholder="Sub Class" rel="'+count+'" data-validation="required" data-validation-error-msg-container="#class-'+count+'-error" onkeyup="uniqueness('+count+')" />' +
								'<span id="class-'+count+'-error"></span>' +
							'</div>' +
						'</div>' +
						'<div class="col-md-4">' +
							'<div class="form-group">' +
								'<label class="control-label">Status <sup>*</sup></label>' +
								'<select name="status[]" class="form-control select2" title="- - Select Status - -" data-validation="required">' +
									'<option value="" disabled>- - Select Status - -</option>' +
									'<option value="1" <?php if($model->status) { echo "selected"; } ?>>Active</option>' +
									'<option value="0" <?php if(!$model->status) { echo "selected"; } ?>>Inactive</option>' +
								'</select>' +
							'</div>' +
						'</div>' +
					'</div>' +
					'<div class="row">' +
						'<div class="col-md-3">' +
							'<div class="form-group">' +
								'<label class="control-label">Departure Date <sup>*</sup></label>' +
								'<div class="input-group">' +
									'<input type="text" name="depart_from[]" class="form-control dateonlyclone" placeholder="From" value="<?=$model->depart_from?>" data-validation="required" data-validation-error-msg-container="#depart-from-error-'+clone+'" readonly />' +
									'<span class="input-group-addon">' +
										'<span class="glyphicon glyphicon-calendar"></span>' +
									'</span>' +
								'</div>' +
								'<span id="depart-from-error-'+clone+'"></span>' +
							'</div>' +
						'</div>' +
						'<div class="col-md-3">' +
							'<div class="form-group">' +
								'<label class="control-label">Departure Date <sup>*</sup></label>' +
								'<div class="input-group">' +
									'<input type="text" name="depart_till[]" class="form-control dateonlyclone" placeholder="To" value="<?=$model->depart_till?>" data-validation="required" data-validation-error-msg-container="#depart-till-error" readonly />' +
									'<span class="input-group-addon">' +
										'<span class="glyphicon glyphicon-calendar"></span>' +
									'</span>' +
								'</div>' +
								'<span id="depart-till-error-'+clone+'"></span>' +
							'</div>' +
						'</div>' +
						'<div class="col-md-3">' +
							'<div class="form-group">' +
								'<label class="control-label">Starting Date <sup>*</sup></label>' +
								'<div class="input-group">' +
									'<input type="text" name="start_date[]" class="form-control dateonlyclone" placeholder="Starting Date" value="<?=$model->start_date?>" data-validation="required" data-validation-error-msg-container="#startfrom-error-'+clone+'" readonly />' +
									'<span class="input-group-addon">' +
										'<span class="glyphicon glyphicon-calendar"></span>' +
									'</span>' +
								'</div>' +
								'<span id="startfrom-error-'+clone+'"></span>' +
							'</div>' +
						'</div>' +
						'<div class="col-md-3">' +
							'<div class="form-group">' +
								'<label class="control-label">Expiry Date <sup>*</sup></label>' +
								'<div class="input-group">' +
									'<input type="text" name="expiry_date[]" class="form-control dateonlyclone" placeholder="Expiry Date" value="<?=$model->expiry_date?>" data-validation="required" data-validation-error-msg-container="#expireon-error-'+clone+'" readonly />' +
									'<span class="input-group-addon">' +
										'<span class="glyphicon glyphicon-calendar"></span>' +
									'</span>' +
								'</div>' +
								'<span id="expireon-error-'+clone+'"></span>' +
							'</div>' +
						'</div>' +
					'</div>' +
				'</div>' +
				'<div class="col-md-12"><hr></div>' +
			'</div>'
		);
		$('.select2').selectpicker('refresh');
		$('.dateonlyclone').datetimepicker({
			showClose: false,
			showClear: false,
			useCurrent: false,
			format: 'YYYY-MM-DD',
			ignoreReadonly: true,
		});
		$("input#clones").val(count);
	});
		
	$('body').on('click','button#clone-delete',function() {
		var count = $("div.bb-middle").children().length - 1;
		$("div#clone-"+count).remove();
		if(count != 1) { count -= 1; }
		$("input#clones").val(count);
	});
	<?php } ?>
	
</script>
<?php } ?>
<?php if($this->uri->segment(1) == 'ma_flight_inventory') { ?>
<script type="text/javascript">
	$('select#stops').on('change', function() {
		if ($(this).val().trim() == 2) {
			$('div.round-trip').show();
			$('div.round-stop').show();
			$('div.multi-stop').hide();
			$('div.onewy-stop').addClass('col-md-4');
			$('div.round-stop').addClass('col-md-4');
			$('div.onewy-stop').removeClass('col-md-3');
			$('div.round-stop').removeClass('col-md-3');
		} else if ($(this).val().trim() == 3) {
			$('div.round-trip').show();
			$('div.round-stop').show();
			$('div.multi-stop').show();
			$('div.onewy-stop').addClass('col-md-3');
			$('div.round-stop').addClass('col-md-3');
			$('div.onewy-stop').removeClass('col-md-4');
			$('div.round-stop').removeClass('col-md-4');
		} else {
			$('div.round-trip').hide();
			$('div.round-stop').hide();
			$('div.multi-stop').hide();
			$('div.onewy-stop').addClass('col-md-4');
			$('div.onewy-stop').removeClass('col-md-3');
		}
	});
</script>
<script type="text/javascript">
	$('select#origin').on('change', function() {
		$('select#departure_stop_1').val($(this).val()).change();
		$('.select2').selectpicker('refresh');
	});
	$('select#arrival_stop_1').on('change', function() {
		$('select#departure_stop_2').val($(this).val()).change();
		$('.select2').selectpicker('refresh');
	});
	$('select#arrival_stop_2').on('change', function() {
		$('select#departure_stop_3').val($(this).val()).change();
		$('.select2').selectpicker('refresh');
	});
	
	<?php if(isset($model)) { ?>
	$('body').on('click','button#clone-create',function() {
		var count = $("div.bb-middle").children().length;
		var clone = count - 1;
		$("div.bb-middle").append(
			'<div class="clone-tab" id="clone-'+count+'">' +
				'<div class="col-md-3">' +
					'<div class="form-group onewy-stop">' +
						'<input type="text" name="seats['+clone+']" id="seats" class="form-control" placeholder="Enter no. of Seats" value="<?=$model->SeatToSell?>" data-validation="required number length" data-validation-length="max11" />' +
					'</div>' +
					'<div class="form-group onewy-stop">' +
						'<select name="status['+clone+']" class="form-control select2" title="- - Select Status - -" data-validation="required">' +
							'<option value="" disabled>- - Select Status - -</option>' +
							'<option value="1" <?php if($model->status) { echo "selected"; } ?>>Active</option>' +
							'<option value="0" <?php if(!$model->status) { echo "selected"; } ?>>Inactive</option>' +
						'</select>' +
					'</div>' +
				'</div>' +
				'<div class="col-md-3">' +
					'<div class="form-group onewy-stop">' +
						'<select name="cabin['+clone+'][]" class="form-control select2" title="- - Select - -" data-live-search="true" data-validation="required" data-validation-error-msg-container="#cabin-error-one-'+count+'">' +
							'<option value="C" <?php if(isset($model->Cabin[0]) && $model->Cabin[0] == "C") { echo "selected"; } ?>>Business</option>' +
							'<option value="Y" <?php if(isset($model->Cabin[0]) && $model->Cabin[0] == "Y") { echo "selected"; } ?>>Economy</option>' +
							'<option value="F" <?php if(isset($model->Cabin[0]) && $model->Cabin[0] == "F") { echo "selected"; } ?>>First Class</option>' +
							'<option value="J" <?php if(isset($model->Cabin[0]) && $model->Cabin[0] == "J") { echo "selected"; } ?>>Premium Business</option>' +
							'<option value="S" <?php if(isset($model->Cabin[0]) && $model->Cabin[0] == "S") { echo "selected"; } ?>>Premium Economy</option>' +
							'<option value="P" <?php if(isset($model->Cabin[0]) && $model->Cabin[0] == "P") { echo "selected"; } ?>>Premium First Class</option>' +
						'</select>' +
						'<span id="cabin-error-one-'+count+'"></span>' +
					'</div>' +
					'<div class="form-group round-stop">' +
						'<select name="cabin['+clone+'][]" class="form-control select2" title="- - Select - -" data-live-search="true" data-validation="required" data-validation-error-msg-container="#cabin-error-two-'+count+'">' +
							'<option value="C" <?php if(isset($model->Cabin[1]) && $model->Cabin[1] == "C") { echo "selected"; } ?>>Business</option>' +
							'<option value="Y" <?php if(isset($model->Cabin[1]) && $model->Cabin[1] == "Y") { echo "selected"; } ?>>Economy</option>' +
							'<option value="F" <?php if(isset($model->Cabin[1]) && $model->Cabin[1] == "F") { echo "selected"; } ?>>First Class</option>' +
							'<option value="J" <?php if(isset($model->Cabin[1]) && $model->Cabin[1] == "J") { echo "selected"; } ?>>Premium Business</option>' +
							'<option value="S" <?php if(isset($model->Cabin[1]) && $model->Cabin[1] == "S") { echo "selected"; } ?>>Premium Economy</option>' +
							'<option value="P" <?php if(isset($model->Cabin[1]) && $model->Cabin[1] == "P") { echo "selected"; } ?>>Premium First Class</option>' +
						'</select>' +
						'<span id="cabin-error-two-'+count+'"></span>' +
					'</div>' +
					'<div class="form-group multi-stop">' +
						'<select name="cabin['+clone+'][]" class="form-control select2" title="- - Select - -" data-live-search="true" data-validation="required" data-validation-error-msg-container="#cabin-error-thr-'+count+'">' +
							'<option value="C" <?php if(isset($model->Cabin[2]) && $model->Cabin[2] == "C") { echo "selected"; } ?>>Business</option>' +
							'<option value="Y" <?php if(isset($model->Cabin[2]) && $model->Cabin[2] == "Y") { echo "selected"; } ?>>Economy</option>' +
							'<option value="F" <?php if(isset($model->Cabin[2]) && $model->Cabin[2] == "F") { echo "selected"; } ?>>First Class</option>' +
							'<option value="J" <?php if(isset($model->Cabin[2]) && $model->Cabin[2] == "J") { echo "selected"; } ?>>Premium Business</option>' +
							'<option value="S" <?php if(isset($model->Cabin[2]) && $model->Cabin[2] == "S") { echo "selected"; } ?>>Premium Economy</option>' +
							'<option value="P" <?php if(isset($model->Cabin[2]) && $model->Cabin[2] == "P") { echo "selected"; } ?>>Premium First Class</option>' +
						'</select>' +
						'<span id="cabin-error-thr-'+count+'"></span>' +
					'</div>' +
				'</div>' +
				'<div class="col-md-3">' +
					'<div class="form-group onewy-stop">' +
						'<div class="input-group date datetimepicker">' +
							'<input type="text" name="check_in['+clone+'][]" class="form-control departure_date" placeholder="Date & Time" value="<?php if(isset($model->DepartureDateTime[0])) { echo $model->DepartureDateTime[0]; } ?>" data-validation="required" data-validation-error-msg-container="#checkin-error-one-'+count+'" readonly />' +
							'<span class="input-group-addon">' +
								'<span class="glyphicon glyphicon-calendar"></span>' +
							'</span>' +
						'</div>' +
						'<span id="checkin-error-one-'+count+'"></span>' +
					'</div>' +
					'<div class="form-group round-stop">' +
						'<div class="input-group date datetimepicker">' +
							'<input type="text" name="check_in['+clone+'][]" class="form-control departure_date" placeholder="Date & Time" value="<?php if(isset($model->DepartureDateTime[1])) { echo $model->DepartureDateTime[1]; } ?>" data-validation="required" data-validation-error-msg-container="#checkin-error-two-'+count+'" readonly />' +
							'<span class="input-group-addon">' +
								'<span class="glyphicon glyphicon-calendar"></span>' +
							'</span>' +
						'</div>' +
						'<span id="checkin-error-two-'+count+'"></span>' +
					'</div>' +
					'<div class="form-group multi-stop">' +
						'<div class="input-group date datetimepicker">' +
							'<input type="text" name="check_in['+clone+'][]" class="form-control departure_date" placeholder="Date & Time" value="<?php if(isset($model->DepartureDateTime[2])) { echo $model->DepartureDateTime[2]; } ?>" data-validation="required" data-validation-error-msg-container="#checkin-error-thr-'+count+'" readonly />' +
							'<span class="input-group-addon">' +
								'<span class="glyphicon glyphicon-calendar"></span>' +
							'</span>' +
						'</div>' +
						'<span id="checkin-error-thr-'+count+'"></span>' +
					'</div>' +
				'</div>' +
				'<div class="col-md-3">' +
					'<div class="form-group onewy-stop">' +
						'<div class="input-group date datetimepicker">' +
							'<input type="text" name="checkout['+clone+'][]" class="form-control arrival_date" placeholder="Date & Time" value="<?php if(isset($model->ArrivalDateTime[0])) { echo $model->ArrivalDateTime[0]; } ?>" data-validation="required" data-validation-error-msg-container="#checkout-error-one-'+count+'" readonly />' +
							'<span class="input-group-addon">' +
								'<span class="glyphicon glyphicon-calendar"></span>' +
							'</span>' +
						'</div>' +
						'<span id="checkout-error-one-'+count+'"></span>' +
					'</div>' +
					'<div class="form-group round-stop">' +
						'<div class="input-group date datetimepicker">' +
							'<input type="text" name="checkout['+clone+'][]" class="form-control arrival_date" placeholder="Date & Time" value="<?php if(isset($model->ArrivalDateTime[1])) { echo $model->ArrivalDateTime[1]; } ?>" data-validation="required" data-validation-error-msg-container="#checkout-error-two-'+count+'" readonly />' +
							'<span class="input-group-addon">' +
								'<span class="glyphicon glyphicon-calendar"></span>' +
							'</span>' +
						'</div>' +
						'<span id="checkout-error-two-'+count+'"></span>' +
					'</div>' +
					'<div class="form-group multi-stop">' +
						'<div class="input-group date datetimepicker">' +
							'<input type="text" name="checkout['+clone+'][]" class="form-control arrival_date" placeholder="Date & Time" value="<?php if(isset($model->ArrivalDateTime[2])) { echo $model->ArrivalDateTime[2]; } ?>" data-validation="required" data-validation-error-msg-container="#checkout-error-thr-'+count+'" readonly />' +
							'<span class="input-group-addon">' +
								'<span class="glyphicon glyphicon-calendar"></span>' +
							'</span>' +
						'</div>' +
						'<span id="checkout-error-thr-'+count+'"></span>' +
					'</div>' +
				'</div>' +
				'<div class="col-md-12"><hr></div>' +
			'</div>'
		);
		$('.select2').selectpicker('refresh');
		$("input#clones").val(count);
	});
		
	$('body').on('click','button#clone-delete',function() {
		var count = $("div.bb-middle").children().length - 1;
		$("div#clone-"+count).remove();
		if(count != 1) { count -= 1; }
		$("input#clones").val(count);
	});
	<?php } ?>
	
</script>
<?php } ?>

<?php if($this->uri->segment(1) == 'ma_subclass_blocking') { ?>
<script type="text/javascript">

	$('.select2airline').selectpicker().ajaxSelectPicker({
		ajax: {
			url: "<?=site_url('ma_subclass_blocking/ajaxloader')?>",
			type: 'POST',
			dataType: 'json',
			data: {
				airline : '{{{q}}}'
			}
		},

		// function to preprocess JSON data
		preprocessData: function (data) {
			var i, l = data.length,
				array = [];
			if (l) {
				for (i = 0; i < l; i++) {
					array.push($.extend(true, data[i], {
						text: data[i].code,
						value: data[i].code,
						data: {
							subtext: data[i].text
						}
					}));
				}
			}
			return array;
		}

	});
	
	$('body').on('click','button#row-create',function() {
		var count = $("div.row-insert").children().length;
		var clone = count - 1;
		$("div.row-insert").append(
			'<div class="row" id="class-'+count+'">' +
				'<div class="form-group">' +
					'<div class="row">' +
						'<div class="col-lg-7">' +
							'<input type="text" name="subclass[]" id="subclass-'+clone+'" class="form-control subclass" placeholder="Enter" data-validation="required" data-validation-error-msg-container="#subclass-'+clone+'-error" />' +
							'<span id="subclass-'+clone+'-error"></span>' +
						'</div>' +
					'</div>' +
				'</div>' +
			'</div>'
		);
	});
		
	$('body').on('click','button#row-delete',function() {
		var count = $("div.row-insert").children().length - 1;
		$("div#class-"+count).remove();
		if(count != 1) { count -= 1; }
	});
	
	$('body').on('keyup','input.subclass',function() {
		var airline = $('select#airline :selected').val();
		var element = $(this).attr('id');
		if( airline && $(this).val().trim() ) {
			$.ajax({
				type: 'post',
				url: "<?=site_url('ma_subclass_blocking/ajaxunique')?>",
				data: { "airline" : airline, "subclass" : $(this).val().trim() },
				dataType: 'json',
				beforeSend: function() {
					$('input#'+element).removeClass('error');
					$('input#'+element).css('border-color', '');
					$('span#'+element+'-error').removeClass('has-success');
					$('span#'+element+'-error').removeClass('has-error');
					$('span#'+element+'-error').html('');
				},
				success: function (result) {
					if (result.message) {
						$('input#'+element).addClass('error');
						$('input#'+element).css('border-color', 'rgb(185, 74, 72)');
						$('span#'+element+'-error').addClass('has-error');
						$('span#'+element+'-error').html('<span class="help-block form-error">'+result.message+'</span>');
					}
				},
			});
		}
	});
	
</script>
<?php } ?>

<script type="text/javascript">
<?php if($this->uri->segment(1) == 'flight_management') { 
$con1="(status='1')";
$datas['pn']=$pn=$this->booking_model->select1("pcc_management",$con1);
$pcc='<option value="">Select PCC</option>';$supplier='<option value="">Select Supplier</option>';
foreach($pn->result() as $row){
	$pcc .= '<option value="'.$row->pcc.'">'.$row->pcc.'</option>';
	$supplier .= '<option value="'.$row->supplier.'">'.$row->supplier.'</option>';

}?> 
	$('body').on('click','button#clone-create',function() {
		
		var count = $("div#a1").children().length;
		var clone = count - 1;
		var radio = count + 1;
		var widget = '<div class="bootstrap-timepicker-widget dropdown-menu"><table><tbody><tr><td><a href="#" data-action="incrementHour"><i class="glyphicon glyphicon-chevron-up"></i></a></td><td class="separator">&nbsp;</td><td><a href="#" data-action="incrementMinute"><i class="glyphicon glyphicon-chevron-up"></i></a></td></tr><tr><td><span class="bootstrap-timepicker-hour">17</span></td><td class="separator">:</td><td><span class="bootstrap-timepicker-minute">15</span></td></tr><tr><td><a href="#" data-action="decrementHour"><i class="glyphicon glyphicon-chevron-down"></i></a></td><td class="separator"></td><td><a href="#" data-action="decrementMinute"><i class="glyphicon glyphicon-chevron-down"></i></a></td></tr></tbody></table></div>';
		$("div#a1").append(
			'<div class="row clone-tab" id="clone-'+count+'">' +
			'<div class="col-md-2">'+
				'<div class="form-group">'+
					'<input type="text" name="air[]" class="form-control" placeholder="Airline PNR">'+
						'</div>'+
			'</div>'+
			'<div class="col-md-2">'+
				'<input type="text" name="pnr1[]" class="form-control" placeholder="PNR" data-validation="required">'+
			'</div>'+
			'<div class="col-md-2">'+
				'<div class="form-group">'+
					'<select name="pcc1[]" class="form-control" data-validation="required" onChange="act1(this.value,'+count+');">'+
						'<?=$pcc?>'+
				    '</select>'+
				'</div>'+
			'</div>'+
			'<div class="col-md-2">'+
				'<div class="form-group">'+
				 '<div id="txtmsg'+count+'">'+
					'<select name="supplier1[]" class="form-control">'+
						'<option value="">Select Supplier</option>'+
				    '</select>'+
					'</div>'+
				'</div>'+
			'</div>'+
			'<div class="col-md-2">'+
				'<div class="form-group">'+
					'<select name="chance[]" class="form-control" placeholder="PNR Chance" data-validation="required">'+
						'<option value="">PNR Chance</option>'+
						'<option value="No">No</option>'+
						'<option value="Yes">Yes</option>'+
						
					'</select>'+
				'</div>'+
			'</div>'+
			'<div class="col-md-2">'+
				'<div class="form-group">'+
					'<div class="input-group">'+                               
			         	'<div class="input-group-addon">'+
			         		'<i class="fa fa-calendar"></i>'+
			         		 '</div>'+
			         		'<input type="text" name="pdate[]" class="form-control datepick1 pull-right" placeholder="yyyy-mm-dd" data-validation="required">'+
			            '</div>'+
			        '</div>'+
			'</div>'+
			'<div class="clearfix"></div>'+
            '<br>'+
			'<div class="col-md-2">'+
				'<div class="bootstrap-timepicker">'+ widget +
					'<div class="form-group">'+
						'<input type="text" name="time[]" class="form-control timepicker2" placeholder="Time"  data-validation="number">'+
					 '</div>'+
				'</div>'+
			'</div>'+
			'<div class="col-md-2">'+
				'<div class="form-group">'+
					'<textarea name="remarks[]" class="form-control" placeholder="Remarks" data-validation="required">'+
					 '</textarea>'+
				'</div>'+
			'</div>'+
			
			
			
			'</div>'
			
		);
		$("input#clones").val(count);
		$('.datepick1').datepicker({
      		format: "yyyy-mm-dd"
    	});
	});
		
	$('body').on('click','button#clone-delete',function() {
		var count = $("div#a1").children().length - 1;
		$("div#clone-"+count).remove();
		if(count != 1) { count -= 1; }
		$("input#clones").val(count);
	});
<?php }?>	
</script>
  <script >
 function act1(str1,str)
{
  //alert(str1);
  var txtid="txtmsg"+str+"";
if (str1=="")
  {
  document.getElementById(txtid).innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById(txtid).innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","<?php echo site_url('flight_management/supplier');?>/"+str1,true);
xmlhttp.send();
}
</script>
<?php if($this->uri->segment(1) == 'flight_management') { ?>
<script type="text/javascript">
	$('body').on('focus',".timepicker2", function(){
		$(this).timepicker({
	      showInputs: false,
	      showMeridian: false,
	      minuteStep: 1,
	    });
	});
	$('body').on('change', '#timepicker1', function() {
		if(this.value != '00:00') {
			filters();
		}
	});
	$('body').on('change', '#timepicker2', function() {
		if(this.value != '00:00') {
			filters();
		}
	});
	function resizeIframe(obj) {
		var iframe = $(window.top.document).find("#discountFrame");
		iframe.height(iframe[0].contentDocument.body.scrollHeight + 'px');
	}
	function filters()
	{
		var status	= $.trim($('#stat').val());
		var tfrom	= $.trim($('#timepicker1').val());
		var tto	= $.trim($('#timepicker2').val());
		var exdate	= $.trim($('#datepick1').val());
		var list	= $.trim($('#lis').val());
		var credate	= $.trim($('#datepick2').val());

		var iframeUrl = '<?php echo site_url(); ?>flight_management/filter_booking?status=' + status +'&tfrom=' + tfrom + '&tto=' + tto + '&exdate=' + exdate + '&list=' + list + '&credate=' + credate +'';
		$("#discountable").html('');
        var map = '<iframe id="discountFrame" frameborder="0" width="100%" scrolling="no" onload="$(document).ready(function(){resizeIframe(this);});" src="' + iframeUrl + '"></iframe>';
		$("#discountable").html(map);
	}
	function info_pnr(pid)
  {
   $.ajax({
	  url: "<?php echo site_url('flight_management/pnr_display');?>",
	  type: "POST",
	  data: {pnrid: pid},
	  dataType: "json",
	  success: function(response){
   
	  $("#info_table").html(response);
	  $("#info_limit").modal('show');

	   }
    });
  }
</script>
<?php } ?>	
<?php if($this->uri->segment(1) == 'holiday_package') { ?>
<script>
function resizeIframe(obj) {
		var iframe = $(window.top.document).find("#discountFrame");
		iframe.height(iframe[0].contentDocument.body.scrollHeight + 'px');
	}
	 function filters1()
	{
		var status	= $.trim($('#stat').val());
		var list	= $.trim($('#lis').val());
		var credate	= $.trim($('#datepick2').val());

		var iframeUrl = '<?php echo site_url(); ?>holiday_package/filter_booking?status=' + status + '&list=' + list + '&credate=' + credate +'';
		$("#discountable").html('');
        var map = '<iframe id="discountFrame" frameborder="0" width="100%" scrolling="no" onload="$(document).ready(function(){resizeIframe(this);});" src="' + iframeUrl + '"></iframe>';
		$("#discountable").html(map);
	}
</script>
<?php } ?>

<!--  </script>-->
  
   <!--new design Bootstrap Bundle with Popper -->
  