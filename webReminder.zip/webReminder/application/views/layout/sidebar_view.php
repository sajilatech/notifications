<style>
  .nav-link.active {
    background-color: #343a40;
    color: white;
}

.nav-link.active i {
    color: white;
}

</style>

 <div class="row">
        <div class="col-2">
          <nav id="sidebar" class=" d-md-block  sidebar">
            <ul class="nav flex-column">
      
                <li class="nav-item">
                <a href="#" class="active" >
                  <i class="icons dashboard"></i>Dashboard  <i class="lni lni-chevron-right"></i></a>
              </li>
           
          
         <?php $title="";?>
  
                    <li class="nav-item">
                    <a href="#submenu111" 
                    data-bs-toggle="collapse" 
                    class="<?= $title == 'SMS' ? 'active' : ''; ?>" 
                    aria-expanded="<?= $title == 'SMS' ? 'true' : 'false'; ?>">
                    <i class="fas fa-users"></i>&nbsp; &nbsp;&nbsp;Events
                        <i class="lni lni-chevron-right"></i>
                    </a>
                    <ul class="collapse list-unstyled <?= $title == 'Events' ? 'show' : ''; ?>" id="submenu111">
                    <li class="nav-item">
                            <a class="nav-link" href="<?=base_url('events')?>">
                                Events
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?=base_url('sms')?>">
                                SMS
                            </a>
                        </li>
                    </ul>
                    </li>
                   
                   
                    </ul>
                    </li>
            
   
    
          
            </ul>

          </nav>
     
        </div>
        
      