<?php // Path to the application folder
$application_folder = 'application';

// Load Composer's autoloader
require_once __DIR__ . '/vendor/autoload.php';

// CI system path definition and initialization continues here...
?>