<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Event_model extends CI_Model
{
   
    function __construct()
    {
        parent::__construct();
    }

  function insert_data($table,$data)
	{ 
        $this->db->insert($table, $data);
 // echo $this->db->last_query(); exit;
        $pri_id=$this->db->insert_id();
        return $pri_id;
        
	}
    function alter($table, $condi, $fields){
        $this->db->where($condi);
        $this->db->update($table, $fields);
  // echo $this->db->last_query();exit;
        $afftectedRows = $this->db->affected_rows();
        return $afftectedRows; 
    }
    function check_exists($table, $conditions) {
        $this->db->from($table);
        $this->db->where($conditions);
        return $this->db->count_all_results();
    }

    function get_all($table, $select,$condi){
        $this->db->select($select);
        $this->db->from($table);
        $this->db->where($condi);
        $query = $this->db->get();
  
        return  $query->result();
    }

    function get_all_by_order($table, $select,$condi, $order_by, $order){
        $this->db->select($select);
        $this->db->from($table);
        if (!empty($condi)) {
            $this->db->where($condi);
        }
        
       
        $this->db->order_by($order_by, $order);
        $query = $this->db->get();
   //echo $this->db->last_query();exit;
        return  $query->result();
    }

    function pagination_get_all($table, $select, $con, $limit, $start, $order_colum, $order_by){
        $this->db->select($select);
        $this->db->where($con);
        $this->db->from($table);
        $this->db->order_by($order_colum, $order_by);
        $this->db->limit($limit,$start);
        $query = $this->db->get();
     
        return $query->result();
    }

    function get_row_by_id($table, $select, $condi){
        $this->db->select($select);
        $this->db->where($condi);
        $this->db->from($table);
        $query = $this->db->get();
     //echo $this->db->last_query();exit;
        $row = $query->row(); 
        return $row;
      }

}