<?php
class User_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    public function checkUser($data) { 
        $this->db->where('oauth_provider', $data['oauth_provider']);
        $this->db->where('oauth_uid', $data['oauth_uid']);
        $query = $this->db->get('users');

        if ($query->num_rows() > 0) {
            $this->db->where('oauth_provider', $data['oauth_provider']);
            $this->db->where('oauth_uid', $data['oauth_uid']);
            $this->db->update('users', array(
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $data['email'],
                'picture' => $data['picture'],
                'modified' => date('Y-m-d H:i:s')
            ));
            return $query->row()->id;
        } else {
            $data['created'] = date('Y-m-d H:i:s');
            $data['modified'] = date('Y-m-d H:i:s');
            $this->db->insert('users', $data);
            return $this->db->insert_id();
        }
    }
}
?>