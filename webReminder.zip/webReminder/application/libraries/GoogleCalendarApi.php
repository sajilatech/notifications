<?php
require_once FCPATH . 'vendor/autoload.php'; // Adjust if your autoload.php is elsewhere

use Google\Client;
use Google\Service\Calendar;

class GoogleCalendarApi {

    public function __construct() {
        // You could initialize some defaults here if needed
    }

    // Get Access Token from authorization code
    public function getAccessToken($clientId, $redirectUri, $clientSecret, $code) {
        $client = new Client();
        $client->setClientId($clientId);
        $client->setClientSecret($clientSecret);
        $client->setRedirectUri($redirectUri);
        $client->addScope(Calendar::CALENDAR);
        $client->addScope('https://www.googleapis.com/auth/userinfo.profile');
        $client->addScope('https://www.googleapis.com/auth/userinfo.email');

        $token = $client->fetchAccessTokenWithAuthCode($code);
        return $token;
    }

    // Get the user's Calendar Timezone
    public function getUserCalendarTimezone($accessToken) {
        $client = new Client();
        $client->setAccessToken($accessToken);

        $service = new Calendar($client);
        $calendar = $service->calendarList->get('primary');
        return $calendar->getTimeZone();
    }

    // Create Calendar Event
    public function createCalendarEvent($accessToken, $calendarId, $calendarEvent, $allDay, $eventDateTime, $timezone) {
        $client = new Client();
        $client->setAccessToken($accessToken);

        $service = new Calendar($client);

        $event = new Calendar\Event([
            'summary' => $calendarEvent['summary'],
            'location' => $calendarEvent['location'],
            'description' => $calendarEvent['description'],
        ]);

        if ($allDay) {
            $event->setStart([
                'date' => $eventDateTime['event_date'],
                'timeZone' => $timezone
            ]);
            $event->setEnd([
                'date' => $eventDateTime['event_date'],
                'timeZone' => $timezone
            ]);
        } else {
            $event->setStart([
                'dateTime' => $eventDateTime['event_date'] . 'T' . $eventDateTime['start_time'],
                'timeZone' => $timezone
            ]);
            $event->setEnd([
                'dateTime' => $eventDateTime['event_date'] . 'T' . $eventDateTime['end_time'],
                'timeZone' => $timezone
            ]);
        }

        $createdEvent = $service->events->insert($calendarId, $event);
        return $createdEvent->getId();
    }
}
