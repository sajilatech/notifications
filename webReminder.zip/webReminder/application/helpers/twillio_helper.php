<?php
use Twilio\Rest\Client;

if (!function_exists('send_message')) {
    
    function send_message($message, $to)
    {
        $CI =& get_instance();
        $CI->load->config('twillio');

        $sid    = $CI->config->item('sid');
        $token  = $CI->config->item('token');
        $tphone = $CI->config->item('twillio_phone');

        $twillio_client = new Client($sid, $token);

        try {
            $twillio_client->messages->create(
                $to,
                array(
                    'from' => $tphone,
                    'body' => $message
                )
            );
            return "Message sent successfully!";
        } catch (Exception $e) {
            return "Error: " . $e->getMessage();
        }
    }
}
