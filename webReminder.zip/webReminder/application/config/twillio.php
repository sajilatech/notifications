
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['sid']       = 'ACab0349cfa02296685ed3de2c31726253';
$config['token']     = 'ea8155d74a7935d2089106cfe8717e95';
$config['twillio_phone'] = '+16812400860';

?>