
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']     = '346923963714-uqfravptij76rfjvopt0m2ivue9k5e92.apps.googleusercontent.com';
$config['google_client_secret'] = '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';
$config['google_redirect_uri']  = base_url('auth/callback');
$config['google_scopes']        = array(
    'email',
    'profile'
);
