<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . '../vendor/autoload.php'; 
class Calender extends CI_Controller {
   
    public function _construct (){
        parent::_construct();
        
        $this->load->helper('url');

    }

	
    public function index() {
        // check if user is logged in
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/index');
        }
        
        // Initialize the Google client
        $client = new Google_Client();
        $client->setClientId('346923963714-uqfravptij76rfjvopt0m2ivue9k5e92.apps.googleusercontent.com');
        $client->setClientSecret('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');
        
        
        
        // Get access token from session
        $token = $this->session->userdata('access_token');
        
        // If no token found, redirect to login
        if (!$token) {
            redirect('auth/index');
        }
        
        // Set the access token on the client
        $client->setAccessToken($token);
       
        
        // If token is expired, redirect to login
        if ($client->isAccessTokenExpired()) {
            $client->revokeToken();
            $this->session->unset_userdata('access_token');
            redirect('auth/index');
        }
        
        // Now ready — create calendar service
       // $calendarService = new Google_Service_Calendar($client);
       // print_r($calendarService);exit;
       
        
        // // List the next 10 events
        // $optParams = [
        //     'maxResults'   => 10,
        //     'orderBy'      => 'startTime',
        //     'singleEvents' => true,
        //     'timeMin'      => date('c')
        // ];
       
        // $events = $calendarService->events->listEvents('primary', $optParams);
     
        // print_r($events);exit;
        // echo "<h3>Your Upcoming Google Calendar Events:</h3>";
        
        // if (count($events->getItems()) == 0) {
        //     echo "<p>No upcoming events found.</p>";
        // } else {
        //     foreach ($events->getItems() as $event) {
        //         $start = $event->getStart()->getDateTime();
        //         if (empty($start)) {
        //             $start = $event->getStart()->getDate(); // all-day events fallback
        //         }
        //         echo "<p><strong>{$event->getSummary()}</strong> — {$start}</p>";
        //     }
        // }
    }   
    
   


  
}
