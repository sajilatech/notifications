<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . '../vendor/autoload.php'; 

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('user_model','model');
    }

    public function index() {
        $this->load->config('google');

$client = new Google_Client();
$client->setClientId($this->config->item('google_client_id'));
$client->setClientSecret($this->config->item('google_client_secret'));
$client->setRedirectUri($this->config->item('google_redirect_uri'));

foreach ($this->config->item('google_scopes') as $scope) {
    $client->addScope($scope);
}


        $data['login_url'] = $client->createAuthUrl();
        $this->load->view('login/login_view', $data);
    }

   

    public function callback() {
        $this->load->config('google');
        $client = new Google_Client();
        $client->setClientId($this->config->item('google_client_id'));
        $client->setClientSecret($this->config->item('google_client_secret'));
        $client->setRedirectUri($this->config->item('google_redirect_uri'));
        foreach ($this->config->item('google_scopes') as $scope) {
            $client->addScope($scope);
        }
         $client->addScope(Google_Service_Calendar::CALENDAR);
         $client->addScope(Google_Service_Calendar::CALENDAR_EVENTS);
         $client->setAccessType('offline');
         $client->setPrompt('consent');
    
        if ($this->input->get('code')) {
            $token = $client->fetchAccessTokenWithAuthCode($this->input->get('code'));
    
            if (isset($token['error'])) {
                $this->session->unset_userdata('access_token');
                redirect('auth/index');
            }
    
            $client->setAccessToken($token);
    
            $this->session->set_userdata('access_token', $token);
    
            if ($client->isAccessTokenExpired()) {
                $client->revokeToken();
                $this->session->unset_userdata('access_token');
                redirect('auth/index');
            }
    
            $oauth = new Google_Service_Oauth2($client);
            $userInfo = $oauth->userinfo->get();
    
            $userData = array(
                'oauth_provider' => 'google',
                'oauth_uid'      => $userInfo->id,
                'first_name'     => $userInfo->givenName,
                'last_name'      => $userInfo->familyName,
                'email'          => $userInfo->email,
                'picture'        => $userInfo->picture
            );
    
            $userID = $this->model->checkUser($userData);
            if ($userID) {
                $this->session->set_userdata([
                    'user_id'   => $userInfo->id,
                    'email'     => $userInfo->email,
                    'name'      => $userInfo->name,
                    'picture'   => $userInfo->picture,
                    
                    'logged_in' => true
                ]);

               
        
             $this->load->view('layout/header_view');
             $this->load->view('layout/sidebar_view');
            $this->load->view('dashboard/dashboard');
            $this->load->view('layout/footer_view');
            } else {
                redirect('auth/index');
            }
    
        } else {
            redirect('auth/index');
        }
    }
    
    public function create_event()
    {
       
        $client = new Google_Client();
        $client->setClientId('346923963714-uqfravptij76rfjvopt0m2ivue9k5e92.apps.googleusercontent.com');
        $client->setClientSecret('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');
        $client->setRedirectUri(base_url('auth/callback')); 
        $client->addScope(Google_Service_Calendar::CALENDAR);
        $client->setAccessType('offline');
        
        if (!$client->getAccessToken()) {
            $authUrl = $client->createAuthUrl();
            redirect($authUrl);
        }

        $service = new Google_Service_Calendar($client);

        $event = new Google_Service_Calendar_Event(array(
            'summary' => 'CodeIgniter Meeting',
            'location' => 'Online',
            'description' => 'A test event created via CodeIgniter',
            'start' => array(
                'dateTime' => '2025-04-20T10:00:00',
                'timeZone' => 'Asia/Kolkata',
            ),
            'end' => array(
                'dateTime' => '2025-04-20T11:00:00',
                'timeZone' => 'Asia/Kolkata',
            ),
            'attendees' => array(
                array('email' => 'example@gmail.com'),
            ),
        ));

        $calendarId = 'primary'; 
        $createdEvent = $service->events->insert($calendarId, $event);

        $resturn= 'Event created: ' . $createdEvent->htmlLink;
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth/index');
    }

    public function test_vendor() {
        echo class_exists('Google_Client') ? 'Google Client is working!' : 'Not found!';
    }
}
?>