<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Twilio\Rest\Client;


class Sms extends CI_Controller {

    var $result;
    var $title;

    public function __construct()
    {
        parent::__construct();
        
        $this->load->library('form_validation');
      
        $this->load->model('event_model', 'model');
      
        $this->load->helper('file_helper');
        $this->load->helper('twillio');
        $this->result=array();
        $this->title="Send SMS";
        $this->clear_cache(); 
    }

    public function index(){
        if(!$this->session->userdata('user_id'))
        {
            redirect('auth/index','refresh'); 
        }
         $admin=$this->session->userdata('user_id');
        $datas['adm']=$admin;
       
        
        $datas['title'] = $this->title;
     
       
        $this->load->view('layout/header_view', $datas);
        $this->load->view('layout/sidebar_view', $datas);
        $this->load->view('events/sms',$datas);
        $this->load->view('layout/footer_view');
    }

   
   public function add(){
    if(!$this->session->userdata('logged_in'))
    {
        redirect('madmin/index','refresh'); 
    }
    
    $datas['title'] = $this->title;
   
    $this->form_validation->set_rules('phone', 'Phone', 'required|numeric|max_length[15]');
     

     if($this->form_validation->run() == FALSE) { 
        $data['errors']=validation_errors();
        $this->load->view('layout/header_view', $datas);
        $this->load->view('layout/sidebar_view', $datas);
        $this->load->view('sms/create',$datas);
        $this->load->view('layout/footer_view');
    }
    else { 
        $phone=$this->input->post('phone');

            $select=array('title','description', 'location','time_from','time_to');
            $condi = array(
                'date >=' => date('Y-m-d H:i:s'),
                'date <=' => date('Y-m-d H:i:s', strtotime('+24 hours')),
                'status'  => 1
            );
            
            $get_rows=$this->model->get_all('events', $select, $condi);
            if(!empty($get_rows)){
                $fields=array('sms_userphone'=>$phone,'sent'=>1);
               
               
            foreach($get_rows as $row){
                $title=$row->title;
                $from_time=$row->time_from;
                $to_time=$row->time_to;
                $location=$row->location;
                $message="The upcoming event ".$title." on the location".$location." From: ". $from_time." To :". $to_time."is near ";
              $result=  send_message($message,$phone);
              
            }
            
            if($result){
                $con=array('sms_userphone'=>$phone, 'sent'=>'1');
                $r=$this->model->check_exists('sms_users', $con);
                if($r>0){

                }
                else{
                    $this->model->insert_data('sms_users', $fields);
                }
               
                $this->session->set_flashdata('success_msg', 'Entries created successfully.');
    				redirect('sms');
            }
            else{
                $this->session->set_flashdata('warning_msg', 'Something went wrong.');
    				redirect('sms');
            }
        }
    }
    }
  
  

   

    function clear_cache()
    {
    $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
    }
}
