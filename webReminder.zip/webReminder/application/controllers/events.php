<?php
defined('BASEPATH') OR exit('No direct script access allowed');




class Events extends CI_Controller {
    var $title;
    var $per_page=10;

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->model('event_model','model');
        $this->load->helper('pagination_helper');
        $this->title="Events";
    }

    public function index() { 
       
        if(!$this->session->userdata('logged_in'))

        {

            redirect('auth/index','refresh');

        }


          $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

		$datas['title']=$this->title;

		$condi = array(); 

            $select = array(

                'id', 

                'title', 

               'location',

                'time_from', 'date',

                'status', 'time_to'


            ); 



        $row =$this->model->get_all_by_order('events', $select , $condi, 'id', 'desc');

        $count=count($row);

        $datas['links']=get_pagination(base_url(). "events/ajax_list/", $count, $this->per_page, 3);

        $get_pagination_result=$this->model->pagination_get_all('events', $select, $condi, $this->per_page, $page,'id','DESC');
        $datas['table_rows']=$get_pagination_result;  
       
        $this->load->view('layout/header_view', $datas);
           $this->load->view('layout/sidebar_view', $datas);
           $this->load->view('events/index',$datas);
           $this->load->view('layout/footer_view');
    }

    function create(){
        if(!$this->session->userdata('logged_in'))

        {
            redirect('auth/index','refresh');

        }

		$datas['title']=$this->title;

		$this->load->view('layout/header_view',$datas);

        $this->load->view('layout/sidebar_view',$datas);

        $this->load->view('events/create',$datas);

        $this->load->view('layout/footer_view');

    }

    function insert(){
        if(!$this->session->userdata('logged_in'))

        {
            redirect('auth/index','refresh');

        }
        $datas['title']=$this->title;
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules('desc', 'Description', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');
        $this->form_validation->set_rules('date', 'Date', 'trim|required');
        $this->form_validation->set_rules('time_from', 'From Time', 'trim|required');
        $this->form_validation->set_rules('time_to', 'To Time', 'trim|required');


        if($this->form_validation->run() == FALSE) { 
           $data['errors']=validation_errors();
           $this->load->view('layout/header_view', $datas);
           $this->load->view('layout/sidebar_view', $datas);
           $this->load->view('events/create',$datas);
           $this->load->view('layout/footer_view');
       }
       else{
        $fields=array(

           
            'title'=>$this->input->post('title'),
            'description'=>$this->input->post('desc'),
            'location'=>$this->input->post('location'),
            'time_from'=>$this->input->post('time_from'),
            'time_to'=>$this->input->post('time_to'),
            'date'=>$this->input->post('date'),
            'created_at'=>date('Y-m-d h:i:s')
            
        );

       $pri_id= $this->model->insert_data('events', $fields);
       if( $pri_id ) {

            $this->session->set_flashdata('success_msg', 'Entries created successfully.');

            redirect('events/edit'."/".$pri_id);

        } else {

            $this->session->set_flashdata('warning_msg', 'Something went wrong.');

            redirect('events/add');

        }
       }
    }

    function edit($id){

        if(!$this->session->userdata('logged_in'))

        {

            redirect('madmin/index','refresh');

        }
        $datas['title']=$this->title;
        $condi=array('id'=>$id); 

        $select = array(

            'id', 
            'title', 

           'description','location',

            'time_from', 'time_to','date',

            'status'

        ); 

       

        $row=$this->model->get_row_by_id('events',$select, $condi);

        $datas['row']=$row;

        $this->load->view('layout/header_view',$datas);
			$this->load->view('layout/sidebar_view',$datas);

			$this->load->view('events/edit',$datas);

			$this->load->view('layout/footer_view');



    }



    function update(){

        $pri_id=$this->input->post('pri_id');

        $condi=array('id'=>$pri_id); 

        $select = array(

            'id', 

            'title', 

           'description','location',

            'time_from', 'time_to','date',

            'status'

        ); 

       

        $row=$this->model->get_row_by_id('events',$select, $condi);

        $datas['row']=$row;

        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules('desc', 'Description', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');
        $this->form_validation->set_rules('date', 'Date', 'trim|required');
        $this->form_validation->set_rules('time_from', 'From Time', 'trim|required');
        $this->form_validation->set_rules('time_to', 'To Time', 'trim|required');


        if($this->form_validation->run() == FALSE) { 
           $data['errors']=validation_errors();
           $this->load->view('layout/header_view', $datas);
           $this->load->view('layout/sidebar_view', $datas);
           $this->load->view('events/edit',$datas);
           $this->load->view('layout/footer_view');
       }
       else{



        $fields=array(

           
            'title'=>$this->input->post('title'),
            'description'=>$this->input->post('desc'),

            'location'=>$this->input->post('location'),

            'time_from'=>$this->input->post('time_from'),

            'time_to'=>$this->input->post('time_to'),

            'date'=>$this->input->post('date'),

            'updated_at'=>date('Y-m-d h:i:s')

            

        );
            $co=array('id'=>$pri_id);

           $this->model->alter('events', $co,  $fields);

           if( $pri_id ) {

                $this->session->set_flashdata('success_msg', 'Entries Updated successfully.');

                redirect('events/edit'."/".$pri_id);

            } else {

                $this->session->set_flashdata('warning_msg', 'Something went wrong.');

                redirect('events/edit'."/".$pri_id);

            }

        }

       

    }
    function status($id, $status){ 

        $condi=array('id'=>$id);

        if($status=='0'){

            $field=array('status'=>1);	

        }

        else{

            $field=array('status'=>0);		

           

        }

        

       $res= $this->model->alter('events',$condi ,$field);

       if($res){

        $this->session->set_flashdata('success_msg', 'Status Updated successfully.');		

        redirect('events');

       }

       else{

        $this->session->set_flashdata('warning_msg', 'Something went wrong.');	

        redirect('events');

       }

       

        

    }

}