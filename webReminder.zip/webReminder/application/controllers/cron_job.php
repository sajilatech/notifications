<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron_job extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('event_model', 'model');
        $this->load->helper('twillio');
    }

    public function index() {
        if (is_cli()) {
            $this->run_cron();
        } else {
            echo "This cron job can only be run via the command line.\n";
        }
    }

    public function run_cron() {
        $select = array('title', 'description', 'location', 'time_from', 'time_to');
        $condi = array(
            'date >=' => date('Y-m-d H:i:s'),
            'date <=' => date('Y-m-d H:i:s', strtotime('+24 hours')),
            'status'  => 1
        );
        
        $get_rows = $this->model->get_all('events', $select, $condi);

        if (!empty($get_rows)) {
            foreach ($get_rows as $row) {
                $title     = $row->title;
                $from_time = $row->time_from;
                $to_time   = $row->time_to;
                $location  = $row->location;

                $message = "The upcoming event '{$title}' at '{$location}' from {$from_time} to {$to_time} is near.";

                $get_phone_numbers = $this->model->get_all_by_order('sms_users', array('sms_userphone'), array(), 'sms_user_id', 'DESC');

                if (!empty($get_phone_numbers)) {
                    foreach ($get_phone_numbers as $phone) {
                        send_message($message, $phone->sms_userphone);
                    }
                }
            }
            echo "Cron job executed successfully.\n";
        } else {
            echo "No upcoming events.\n";
        }
    }
}
