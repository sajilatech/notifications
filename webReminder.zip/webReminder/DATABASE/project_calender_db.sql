-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 20, 2025 at 04:22 PM
-- Server version: 8.2.0
-- PHP Version: 8.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_calender_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `time_from` time NOT NULL,
  `time_to` time NOT NULL,
  `google_calender_event_id` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `location`, `date`, `time_from`, `time_to`, `google_calender_event_id`, `created_at`, `updated_at`, `status`) VALUES
(1, 'Tesing SMS', 'Hi this is a reminder', 'EKM', '2025-04-21', '17:56:20', '20:56:20', NULL, '2025-04-20 11:26:20', '2025-04-20 16:18:33', 1),
(2, 'test2', '', 'Kottayam', '2025-04-22', '10:00:00', '05:00:00', NULL, '2025-04-20 04:17:13', '2025-04-20 16:18:33', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sms_users`
--

DROP TABLE IF EXISTS `sms_users`;
CREATE TABLE IF NOT EXISTS `sms_users` (
  `sms_user_id` int NOT NULL AUTO_INCREMENT,
  `sms_userphone` varchar(50) NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sms_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sms_users`
--

INSERT INTO `sms_users` (`sms_user_id`, `sms_userphone`, `sent`) VALUES
(1, '+919995146157', 1),
(2, '+919746018157', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oauth_provider` varchar(10) NOT NULL,
  `oauth_uid` varchar(50) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `oauth_provider`, `oauth_uid`, `first_name`, `last_name`, `email`, `picture`, `created`, `modified`) VALUES
(1, 'google', '107454888424242508471', 'Web Developer', NULL, 'apidevelopment6@gmail.com', 'https://lh3.googleusercontent.com/a/ACg8ocK7c_h0K_UCR7mN_l2Ts_WLmi6KxXKEgDYvB87RUNJI1I3bpg=s96-c', '2025-04-19 16:12:19', '2025-04-20 14:59:45'),
(2, 'google', '109823314867493772615', 'Sajilaks', 'sysitco', 'sajilakssysitco@gmail.com', 'https://lh3.googleusercontent.com/a/ACg8ocKoK1XpGtSD5D0ycSqjxiC5Qmdw3qad13FFgpLdy6KX0K9_vQ=s96-c', '2025-04-19 16:33:35', '2025-04-19 16:33:35'),
(3, 'google', '100402392432427290722', 'Sajila', 'Sasidharan', 'sajilaanil@gmail.com', 'https://lh3.googleusercontent.com/a/ACg8ocJcoxRU8KcoWHAkEYSGI0dkgH5qqqj_oO_qliNiWNjfRes57-hJ=s96-c', '2025-04-20 11:14:01', '2025-04-20 12:29:05');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
